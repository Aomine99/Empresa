# coding=utf-8
'''

El módulo variables almacena variables que necesitamos
En otros módulos

filacli => Almacena los valores del entry

listcliente => Almacena los valores a mostrar en el preview

treecliente => Almacena el widget que contiene los valores de listcliente

'''


filacli = ()
listclientes = ()
treeclientes = ()
lblerrordni = ()
listado = ()
lbladded = ()
lblfecha = ()
vencalendar = None
calendar = None

filahab = ()
filarbt = ()
listhabitaciones = ()
treehabitaciones = ()
switch = None

# Variable panel
panel = None

# Variables Acerca de

venacercade = None
venfile = None
menubar = None
#vendialog = None
lblmensajedialog = None
vendialogcorrecto = None
ruta = None
venfiledialog = None


# Reservas

semaforo = 0

lblreservasdni = None
lblreservasapellidos = None
listhabitacionescombobox = None
lblnumnoches = None
entcheckin = None
entcheckout = None
btncheckin = None
btncheckout = None
listreservas = None
cmbreserhabitacion = None
filareserva = None
vencalendarr1 = None
vencalendarr2 = None
numhab = None
treereservas = None
saveDni = None

# Variables facturación

lblnochesfac = None
lbldnifacturacion = None
lblapellidosfacturacion = None
lblnombrefacturacion = None
lblcodigoreserva = None
lblhabitacionfacturacion = None
lblfechafacturacion = None
lblunidadesfac = None
lblpreciounidadfac = None
lbltotalunifac = None
datosfactura = None
filafacturacion = None

# Variables Servicios

lblreservaservicio = None
lblhabitacionservicio = None
btnradioalojamiento = None
btnradiodesayuno = None
btnradiocomida = None
btncheckparking = None
enttiposervicio = None
entprecioservicio = None
treeservicios = None
radiobuttonservicios = None
listservicios = None
codigoservicio = None

# Variables Facturación Concepto
lbls0 = None
lbls4 = None
lbls8 = None
lbls12 = None
lbls16 = None
lbls20 = None
lbls24 = None
lbls28 = None
lbls32 = None
lbls36 = None
lbls40 = None
lbls44 = None

# Variables Facturacion Precio
lbls3 = None
lbls7 = None
lbls11 = None
lbls15 = None
lbls19 = None
lbls23 = None
lbls27 = None
lbls31 = None
lbls35 = None
lbls39 = None
lbls43 = None
lbls47 = None

#....
conceptosservicios = None
preciosconcepto = None